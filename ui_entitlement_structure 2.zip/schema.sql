-- schema.sql
CREATE TABLE firm (
    id UUID PRIMARY KEY,
    name VARCHAR NOT NULL,
    code VARCHAR UNIQUE NOT NULL,
    sector VARCHAR,
    attributes JSONB
);

CREATE TABLE identity (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    identity_type VARCHAR NOT NULL,
    identity_value VARCHAR NOT NULL
);

CREATE TABLE org_unit (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    name VARCHAR NOT NULL,
    type VARCHAR,
    parent_id UUID REFERENCES org_unit(id),
    level INT,
    attributes JSONB
);

CREATE TABLE user_org_assignment (
    id UUID PRIMARY KEY,
    identity_id UUID REFERENCES identity(id),
    org_unit_id UUID REFERENCES org_unit(id),
    role_id UUID REFERENCES role(id),
    start_date DATE,
    end_date DATE
);

CREATE TABLE role (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    name VARCHAR NOT NULL,
    application_id UUID
);

CREATE TABLE ui_application (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    name VARCHAR NOT NULL,
    code VARCHAR UNIQUE NOT NULL,
    version VARCHAR,
    attributes JSONB
);

CREATE TABLE ui_module (
    id UUID PRIMARY KEY,
    app_id UUID REFERENCES ui_application(id),
    name VARCHAR NOT NULL,
    code VARCHAR NOT NULL,
    description VARCHAR
);

CREATE TABLE ui_screen (
    id UUID PRIMARY KEY,
    module_id UUID REFERENCES ui_module(id),
    name VARCHAR NOT NULL,
    code VARCHAR NOT NULL,
    route VARCHAR
);

CREATE TABLE ui_section (
    id UUID PRIMARY KEY,
    screen_id UUID REFERENCES ui_screen(id),
    name VARCHAR NOT NULL,
    code VARCHAR NOT NULL
);

CREATE TABLE ui_element (
    id UUID PRIMARY KEY,
    screen_id UUID REFERENCES ui_screen(id),
    section_id UUID,
    type VARCHAR,
    code VARCHAR NOT NULL,
    label VARCHAR,
    attributes JSONB
);

CREATE TABLE entitlement_resource (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    app_id UUID REFERENCES ui_application(id),
    module_id UUID REFERENCES ui_module(id),
    screen_id UUID REFERENCES ui_screen(id),
    section_id UUID,
    element_id UUID,
    code VARCHAR,
    type VARCHAR,
    attributes JSONB
);

CREATE TABLE role_entitlement (
    id UUID PRIMARY KEY,
    firm_id UUID REFERENCES firm(id),
    role_id UUID REFERENCES role(id),
    resource_id UUID REFERENCES entitlement_resource(id),
    action VARCHAR,
    conditions JSONB,
    relationship VARCHAR
);
