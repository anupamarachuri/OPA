import { Injectable } from '@angular/core';
import { ENTITLEMENTS_CONFIG } from './entitlement.config';

@Injectable({ providedIn: 'root' })
export class EntitlementService {
  canViewScreen(screenCode: string): boolean {
    return ENTITLEMENTS_CONFIG.modules['budget-mgmt'].screens?.[screenCode]?.entitlements?.view === true;
  }

  canUseElement(screenCode: string, elementCode: string): boolean {
    return ENTITLEMENTS_CONFIG.modules['budget-mgmt'].screens?.[screenCode]?.elements?.[elementCode]?.visible === true;
  }
}
