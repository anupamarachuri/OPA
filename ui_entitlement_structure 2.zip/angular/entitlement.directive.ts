import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { ENTITLEMENTS_CONFIG } from './entitlement.config';

@Directive({ selector: '[hasEntitlement]' })
export class HasEntitlementDirective {
  constructor(private tpl: TemplateRef<any>, private vcr: ViewContainerRef) {}

  @Input() set hasEntitlement(code: string) {
    const hasAccess = ENTITLEMENTS_CONFIG.modules['budget-mgmt'].screens['budget-approval'].elements?.[code]?.visible;
    if (hasAccess) {
      this.vcr.createEmbeddedView(this.tpl);
    } else {
      this.vcr.clear();
    }
  }
}
