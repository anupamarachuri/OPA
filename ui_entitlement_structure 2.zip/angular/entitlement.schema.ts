export interface EntitlementConfig {
  firmCode: string;
  identity: {
    type: string;
    value: string;
  };
  roles: string[];
  modules: {
    [moduleCode: string]: {
      screens: {
        [screenCode: string]: {
          route: string;
          entitlements: {
            [action: string]: boolean;
          };
          elements: {
            [elementCode: string]: {
              [action: string]: any;
            };
          };
        };
      };
    };
  };
}
