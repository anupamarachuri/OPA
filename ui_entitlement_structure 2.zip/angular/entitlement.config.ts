export const ENTITLEMENTS_CONFIG = {
  firmCode: 'gov_india',
  identity: {
    type: 'employee_id',
    value: 'EMP123'
  },
  roles: ['tax_policy_editor'],
  modules: {
    'budget-mgmt': {
      screens: {
        'budget-approval': {
          route: '/budget/approval',
          entitlements: {
            view: true,
            submit: true
          },
          elements: {
            'button:submit-budget': {
              click: true,
              visible: true
            },
            'dropdown:dept-list': {
              load: true,
              options: ['Finance', 'Defence']
            }
          }
        }
      }
    }
  }
};
