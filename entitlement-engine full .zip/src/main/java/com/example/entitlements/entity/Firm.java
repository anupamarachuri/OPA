
package com.example.entitlements.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "firm")
public class Firm {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String code;

    private String sector;

    @Column(columnDefinition = "jsonb")
    private String attributes;

    // Getters and setters
}
