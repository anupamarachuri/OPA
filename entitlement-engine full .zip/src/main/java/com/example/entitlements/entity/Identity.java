
package com.example.entitlements.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "identity")
public class Identity {

    @Id
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "firm_id")
    private Firm firm;

    @Column(name = "identity_type")
    private String identityType;

    @Column(name = "identity_value")
    private String identityValue;
}
