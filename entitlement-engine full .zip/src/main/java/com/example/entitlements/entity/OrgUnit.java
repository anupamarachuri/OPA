
package com.example.entitlements.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "org_unit")
public class OrgUnit {

    @Id
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "firm_id")
    private Firm firm;

    private String name;
    private String type;

    @ManyToOne
    @JoinColumn(name = "parent_id")
    private OrgUnit parent;

    private Integer level;

    @Column(columnDefinition = "jsonb")
    private String attributes;
}
