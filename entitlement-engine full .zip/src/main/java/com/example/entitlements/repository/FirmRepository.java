
package com.example.entitlements.repository;

import com.example.entitlements.entity.Firm;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface FirmRepository extends JpaRepository<Firm, UUID> {
    Firm findByCode(String code);
}
