
package com.example.entitlements.controller;

import com.example.entitlements.model.EntitlementRequest;
import com.example.entitlements.model.EntitlementResponse;
import com.example.entitlements.service.EntitlementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/entitlements")
@Tag(name = "Entitlements", description = "API for entitlement fetch and access evaluation")
public class EntitlementController {

    @Autowired
    private EntitlementService entitlementService;

    @Operation(summary = "Fetch UI entitlements")
    @GetMapping
    public ResponseEntity<EntitlementResponse> getEntitlements(
        @RequestParam String firmCode,
        @RequestParam String identityType,
        @RequestParam String identityValue,
        @RequestParam String applicationId
    ) {
        return ResponseEntity.ok(entitlementService.getEntitlements(firmCode, identityType, identityValue, applicationId));
    }

    @Operation(summary = "Evaluate access using OPA")
    @PostMapping("/evaluate")
    public ResponseEntity<Boolean> evaluateAccess(@RequestBody EntitlementRequest request) {
        return ResponseEntity.ok(entitlementService.evaluateAccess(request));
    }
}
