
package com.example.entitlements.controller;

import com.example.entitlements.model.EntitlementRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(EntitlementController.class)
public class EntitlementControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testEvaluateAccess() throws Exception {
        EntitlementRequest request = new EntitlementRequest();
        request.user = "user123";
        request.resource = "button:approve-budget";
        request.action = "click";
        request.context = Map.of("target_user", "user456");
        request.attributes = Map.of("region", "NA", "seniority", 6);

        mockMvc.perform(post("/entitlements/evaluate")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }
}
