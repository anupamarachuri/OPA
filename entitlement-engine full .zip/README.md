
# Entitlement Engine

A Spring Boot + OPA-based entitlement service for dynamic UI/API access control.

## 🔧 Prerequisites

- Java 17+
- Maven
- Docker (for optional Docker Compose setup)

## 🧱 Run Locally

### Step 1: Build

```bash
mvn clean install
```

### Step 2: Run Spring Boot

```bash
java -jar target/entitlement-engine.jar
```

### Step 3: Swagger UI

Visit: [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

## 🐳 Docker Compose (Recommended)

```bash
cd docker
docker-compose up --build
```

### Services

- PostgreSQL (port: 5432)
- OPA (port: 8181)
- Entitlement Engine API (port: 8080)

## 🧪 Postman Test

Use `postman_collection.json` provided in the repo.

## 🔐 OPA Policy

Edit `docker/opa/entitlements.rego` to update rules.

## ✅ Sample Endpoint

```http
POST /entitlements/evaluate
```

```json
{
  "user": "user123",
  "resource": "button:approve-budget",
  "action": "click",
  "context": { "target_user": "user456" },
  "attributes": { "region": "NA", "seniority": 6 }
}
```
