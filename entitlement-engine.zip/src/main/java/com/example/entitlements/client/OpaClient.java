
package com.example.entitlements.client;

import com.example.entitlements.model.EntitlementRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class OpaClient {

    @Value("${opa.url}")
    private String opaUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public boolean evaluateWithOpa(EntitlementRequest request) {
        String url = opaUrl + "/v1/data/entitlements/allow";
        Map<String, Object> opaRequest = Map.of("input", request);
        ResponseEntity<Map> response = restTemplate.postForEntity(url, opaRequest, Map.class);
        return Boolean.TRUE.equals(((Map<?, ?>) response.getBody().get("result")).get("allow"));
    }
}
