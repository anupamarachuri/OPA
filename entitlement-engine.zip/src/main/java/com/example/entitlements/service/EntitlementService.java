
package com.example.entitlements.service;

import com.example.entitlements.client.OpaClient;
import com.example.entitlements.model.EntitlementRequest;
import com.example.entitlements.model.EntitlementResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EntitlementService {

    @Autowired
    private OpaClient opaClient;

    public EntitlementResponse getEntitlements(String firmCode, String identityType, String identityValue, String applicationId) {
        // Stub: replace with DB logic
        return new EntitlementResponse("gov_india", identityType, identityValue, applicationId, "tax_policy_editor");
    }

    public boolean evaluateAccess(EntitlementRequest request) {
        return opaClient.evaluateWithOpa(request);
    }
}
