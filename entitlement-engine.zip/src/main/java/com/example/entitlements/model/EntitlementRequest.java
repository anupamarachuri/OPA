
package com.example.entitlements.model;

import java.util.Map;

public class EntitlementRequest {
    public String user;
    public String resource;
    public String action;
    public Map<String, Object> context;
    public Map<String, Object> attributes;

    // Getters and setters omitted for brevity
}
