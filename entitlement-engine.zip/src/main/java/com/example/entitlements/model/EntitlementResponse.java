
package com.example.entitlements.model;

public class EntitlementResponse {
    public String firmCode;
    public String identityType;
    public String identityValue;
    public String applicationId;
    public String role;

    public EntitlementResponse(String firmCode, String identityType, String identityValue, String applicationId, String role) {
        this.firmCode = firmCode;
        this.identityType = identityType;
        this.identityValue = identityValue;
        this.applicationId = applicationId;
        this.role = role;
    }
}
