
package com.example.entitlements.controller;

import com.example.entitlements.model.EntitlementRequest;
import com.example.entitlements.model.EntitlementResponse;
import com.example.entitlements.service.EntitlementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/entitlements")
public class EntitlementController {

    @Autowired
    private EntitlementService entitlementService;

    @GetMapping
    public ResponseEntity<EntitlementResponse> getEntitlements(
        @RequestParam String firmCode,
        @RequestParam String identityType,
        @RequestParam String identityValue,
        @RequestParam String applicationId
    ) {
        return ResponseEntity.ok(entitlementService.getEntitlements(firmCode, identityType, identityValue, applicationId));
    }

    @PostMapping("/evaluate")
    public ResponseEntity<Boolean> evaluateAccess(@RequestBody EntitlementRequest request) {
        return ResponseEntity.ok(entitlementService.evaluateAccess(request));
    }
}
