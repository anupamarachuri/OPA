import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ENTITLEMENTS_CONFIG } from './entitlement.config';

@Injectable({ providedIn: 'root' })
export class EntitlementGuard implements CanActivate {
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const screen = route.data['screenCode'];
    return ENTITLEMENTS_CONFIG.modules['budget-mgmt'].screens?.[screen]?.entitlements?.view === true;
  }
}
